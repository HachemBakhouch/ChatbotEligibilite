from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.exceptions import InvalidSignature
import os
import base64

class DigitalSignature:
    """
    Classe pour la gestion des signatures électroniques utilisant le cryptage asymétrique RSA.
    """
    
    @staticmethod
    def generate_key_pair(key_size=2048):
        """
        Génère une nouvelle paire de clés RSA (privée et publique).
        
        Args:
            key_size (int): Taille de la clé en bits (par défaut: 2048)
            
        Returns:
            tuple: (clé_privée, clé_publique)
        """
        # Génération de la clé privée
        private_key = rsa.generate_private_key(
            public_exponent=65537,  # Exposant standard pour RSA
            key_size=key_size
        )
        
        # Dérivation de la clé publique correspondante
        public_key = private_key.public_key()
        
        return private_key, public_key
    
    @staticmethod
    def save_private_key(private_key, filename, password=None):
        """
        Sauvegarde la clé privée dans un fichier, optionnellement protégé par mot de passe.
        
        Args:
            private_key: Clé privée RSA
            filename (str): Chemin du fichier de sortie
            password (str, optional): Mot de passe pour chiffrer la clé
        """
        encryption_algorithm = serialization.NoEncryption()
        if password:
            # Si un mot de passe est fourni, on utilise un chiffrement
            encryption_algorithm = serialization.BestAvailableEncryption(password.encode())
            
        # Sérialisation et sauvegarde de la clé privée
        with open(filename, 'wb') as f:
            f.write(private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=encryption_algorithm
            ))
    
    @staticmethod
    def save_public_key(public_key, filename):
        """
        Sauvegarde la clé publique dans un fichier.
        
        Args:
            public_key: Clé publique RSA
            filename (str): Chemin du fichier de sortie
        """
        # Sérialisation et sauvegarde de la clé publique
        with open(filename, 'wb') as f:
            f.write(public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            ))
    
    @staticmethod
    def load_private_key(filename, password=None):
        """
        Charge une clé privée depuis un fichier.
        
        Args:
            filename (str): Chemin du fichier contenant la clé privée
            password (str, optional): Mot de passe pour déchiffrer la clé
            
        Returns:
            Clé privée RSA
        """
        with open(filename, 'rb') as f:
            private_key_data = f.read()
            
        password_bytes = None
        if password:
            password_bytes = password.encode()
            
        # Désérialisation de la clé privée
        return serialization.load_pem_private_key(
            private_key_data,
            password=password_bytes
        )
    
    @staticmethod
    def load_public_key(filename):
        """
        Charge une clé publique depuis un fichier.
        
        Args:
            filename (str): Chemin du fichier contenant la clé publique
            
        Returns:
            Clé publique RSA
        """
        with open(filename, 'rb') as f:
            public_key_data = f.read()
            
        # Désérialisation de la clé publique
        return serialization.load_pem_public_key(public_key_data)
    
    @staticmethod
    def sign_document(document_path, private_key):
        """
        Signe un document avec une clé privée.
        
        Args:
            document_path (str): Chemin du document à signer
            private_key: Clé privée RSA de l'émetteur
            
        Returns:
            bytes: Signature du document
        """
        # Lecture du contenu du document
        with open(document_path, 'rb') as f:
            document_data = f.read()
        
        # Calcul du hash et signature
        signature = private_key.sign(
            document_data,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        
        return signature
    
    @staticmethod
    def verify_signature(document_path, signature, public_key):
        """
        Vérifie la signature d'un document avec une clé publique.
        
        Args:
            document_path (str): Chemin du document à vérifier
            signature (bytes): Signature à vérifier
            public_key: Clé publique RSA de l'émetteur
            
        Returns:
            bool: True si la signature est valide, False sinon
        """
        # Lecture du contenu du document
        with open(document_path, 'rb') as f:
            document_data = f.read()
        
        try:
            # Vérification de la signature
            public_key.verify(
                signature,
                document_data,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            return True
        except InvalidSignature:
            # Si la signature est invalide, une exception est levée
            return False
    
    @staticmethod
    def save_signature(signature, filename):
        """
        Sauvegarde une signature dans un fichier (encodée en base64).
        
        Args:
            signature (bytes): Signature à sauvegarder
            filename (str): Chemin du fichier de sortie
        """
        # Encodage en base64 pour faciliter le stockage et le transfert
        encoded_signature = base64.b64encode(signature)
        with open(filename, 'wb') as f:
            f.write(encoded_signature)
    
    @staticmethod
    def load_signature(filename):
        """
        Charge une signature depuis un fichier.
        
        Args:
            filename (str): Chemin du fichier contenant la signature
            
        Returns:
            bytes: Signature décodée
        """
        with open(filename, 'rb') as f:
            encoded_signature = f.read()
        
        # Décodage de la signature
        return base64.b64decode(encoded_signature)


# Exemple d'utilisation
def demonstration():
    print("Démonstration de signature électronique de documents")
    print("---------------------------------------------------")
    
    # Création des répertoires pour les clés et documents
    os.makedirs("keys", exist_ok=True)
    os.makedirs("documents", exist_ok=True)
    
    # Génération des paires de clés
    print("1. Génération des paires de clés...")
    emetteur_private, emetteur_public = DigitalSignature.generate_key_pair()
    destinataire_private, destinataire_public = DigitalSignature.generate_key_pair()
    
    # Sauvegarde des clés
    DigitalSignature.save_private_key(emetteur_private, "keys/emetteur_private.pem")
    DigitalSignature.save_public_key(emetteur_public, "keys/emetteur_public.pem")
    DigitalSignature.save_private_key(destinataire_private, "keys/destinataire_private.pem")
    DigitalSignature.save_public_key(destinataire_public, "keys/destinataire_public.pem")
    print("   Clés générées et sauvegardées dans le dossier 'keys/'")
    
    # Création d'un document de test
    document_path = "documents/document_test.txt"
    with open(document_path, 'w') as f:
        f.write("Ceci est un document de test qui sera signé électroniquement.")
    print("2. Document de test créé:", document_path)
    
    # Signature du document
    print("3. Signature du document par l'émetteur...")
    signature = DigitalSignature.sign_document(document_path, emetteur_private)
    signature_path = "documents/signature.bin"
    DigitalSignature.save_signature(signature, signature_path)
    print("   Document signé et signature sauvegardée:", signature_path)
    
    # Vérification de la signature avec la clé publique de l'émetteur
    print("4. Vérification de la signature par le destinataire...")
    loaded_signature = DigitalSignature.load_signature(signature_path)
    verification_result = DigitalSignature.verify_signature(document_path, loaded_signature, emetteur_public)
    
    if verification_result:
        print("   ✅ Signature vérifiée avec succès! Le document est authentique et n'a pas été altéré.")
    else:
        print("   ❌ Échec de la vérification! Le document a été altéré ou la signature est incorrecte.")
    
    # Test avec un document altéré
    print("\n5. Test avec un document altéré...")
    altered_document_path = "documents/document_altere.txt"
    with open(altered_document_path, 'w') as f:
        f.write("Ceci est un document de test qui a été MODIFIÉ après signature.")
    
    verification_result = DigitalSignature.verify_signature(altered_document_path, loaded_signature, emetteur_public)
    
    if verification_result:
        print("   ✅ Signature vérifiée avec succès! Le document est authentique et n'a pas été altéré.")
    else:
        print("   ❌ Échec de la vérification! Le document a été altéré ou la signature est incorrecte.")


if __name__ == "__main__":
    demonstration()
